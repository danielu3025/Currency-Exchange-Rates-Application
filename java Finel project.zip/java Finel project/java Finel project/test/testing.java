package test;
import curr.*;

import static org.junit.Assert.*;
import org.junit.Test;

public class testing {
    @Test
    public void Test(){
        double curr = Calculator.Conversion("10",3.6979,0.0255,100,10);
        //need to update results (the left data) manually
        assertEquals(147.5,curr,3.0);
    }
}
