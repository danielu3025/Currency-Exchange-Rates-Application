package curr;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class Graph{
    Currency[] currencies;
    HistoryManger.CurrencyHistoryObj currencyHistoryObj[];
    String date ;
    JFreeChart lineChart;
    JFrame frame;
    JComboBox cmbCurrCode;
    int currCodeIndex =0;
    ChartPanel chartPanel;
    public Graph(Currency[] currencies_data , String date_info ) throws IOException {
        try {
            currencies = currencies_data;
            date = date_info;
            HistoryManger historyManger = new HistoryManger(currencies,date);
            historyManger.ArchivedCurrenciesInfo();
            currencyHistoryObj = historyManger.LoadDataHistory();
            lineChart = ChartFactory.createLineChart("over-time change", "Date","Rate", createDataset(0), PlotOrientation.VERTICAL, true,true,false);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private DefaultCategoryDataset createDataset(int cIndex )  {
       DefaultCategoryDataset dataset = new DefaultCategoryDataset( );

        for (int i =0 ; i< currencyHistoryObj[cIndex].dates.size();i++){
            dataset.addValue(currencyHistoryObj[cIndex].rates.get(i),currencyHistoryObj[cIndex].name,currencyHistoryObj[cIndex].dates.get(i));
        }
        return dataset;
    }
    public void Disply() throws IOException {


        String currCodeList[] = new String[currencyHistoryObj.length];
        for (int i=0;i<currCodeList.length;i++){
            currCodeList[i] = currencyHistoryObj[i].name;
        }
        cmbCurrCode = new JComboBox(currCodeList);

        CmbCurrListHendler cmbCurrListHendler = new CmbCurrListHendler();
        cmbCurrCode.addActionListener(cmbCurrListHendler);

        chartPanel = new ChartPanel( lineChart );
        chartPanel.setPreferredSize( new java.awt.Dimension( 600 , 400 ));
        frame = new JFrame("");
        frame.setSize(650,500);
        frame.setLayout(new FlowLayout());
        frame.add(chartPanel);
        frame.add(cmbCurrCode);
        frame.setVisible(true);
    }
    private class CmbCurrListHendler implements ActionListener{
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == cmbCurrCode){
                JComboBox cb = (JComboBox) e.getSource();
                currCodeIndex = cb.getSelectedIndex();
                lineChart = ChartFactory.createLineChart("over-time change", "Date","Rate", createDataset(currCodeIndex), PlotOrientation.VERTICAL, true,true,false);
                frame.dispose();
                frame.remove(chartPanel);
                frame.remove(cmbCurrCode);
                chartPanel = new ChartPanel( lineChart );
                frame.add(chartPanel);
                frame.add(cmbCurrCode);

                frame.setVisible(true);
            }
        }
    }
}
