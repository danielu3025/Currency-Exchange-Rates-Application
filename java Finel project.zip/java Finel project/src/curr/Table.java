package curr;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Table extends JFrame {
    JTable table = new JTable();

    DefaultTableModel model = new DefaultTableModel();

    Object[] columns = {"Name", "Unit", "Code", "Country", "Rate", "Change"};

    final JTextField textName = new JTextField();
    final JTextField textUnit = new JTextField();
    final JTextField textCode = new JTextField();
    final JTextField textCountry = new JTextField();
    final JTextField textRate = new JTextField();
    final JTextField textChange = new JTextField();
    final JTextField searchField = new JTextField();
    final JLabel addHint = new JLabel("write to empty fields and tap the 'add' button to add table rows");
    final JLabel searchHint = new JLabel("write to filter");
    final JButton btnAdd = new JButton("Add");
    private TableRowSorter<TableModel> rowSorter;

    Object[] row = new Object[6];
    String[][] data;

    Table(Currency[] currencies,int size){
        model.setColumnIdentifiers(columns);
        table.setModel(model);

        table.setRowHeight(30);

        addHint.setBounds(130,240,682,25);
        searchHint.setBounds(10,335,300,25);

        textName.setBounds(10, 210, 111, 25);
        textUnit.setBounds(121, 210, 111, 25);
        textCode.setBounds(232, 210, 111, 25);
        textCountry.setBounds(343, 210, 111, 25);
        textRate.setBounds(454, 210, 111, 25);
        textChange.setBounds(565, 210, 111, 25);

        searchField.setBounds(10,365,200,25);

        btnAdd.setBounds(290,270,100,25);

        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(10, 10, 682, 200);

        setLayout(new BorderLayout());
        setLayout(new FlowLayout());
        setResizable(false);
        setLayout(null);

        add(pane);

        add(textName);
        add(textChange);
        add(textCode);
        add(textCountry);
        add(textRate);
        add(textUnit);

        add(searchField);
        add(searchHint);

        add(addHint);

        add(btnAdd);


        setSize(700,430);
        setTitle("curr.Currency Exchange Rates- curr.Table");
        setLocationRelativeTo(null);

        data = new String[size][6];
        for (int i = 0; i < size; i++) {
            data[i][0] = currencies[i].getName();
            data[i][1] = Double.toString(currencies[i].getUnit());
            data[i][2] = currencies[i].getCode();
            data[i][3] = currencies[i].getCountry();
            data[i][4] = Double.toString(currencies[i].getRate());
            data[i][5] = Double.toString(currencies[i].getChange());
        }

        model = new DefaultTableModel(data,columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;//This causes all cells to be not editable
            }
        };
        table.setModel(model);
        rowSorter = new TableRowSorter<TableModel>(table.getModel());
        table.setRowSorter(rowSorter);


        // button add row
        btnAdd.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {

                row[0] = textName.getText();
                row[1] = textUnit.getText();
                row[2] = textCode.getText();
                row[3] = textCountry.getText();
                row[4] = textRate.getText();
                row[5] = textChange.getText();


                // add row to the model
                model.addRow(row);

                textName.setText("");
                textUnit.setText("");
                textCode.setText("");
                textCountry.setText("");
                textRate.setText("");
                textChange.setText("");

                JOptionPane.showMessageDialog(null,"Currency added");


            }
        });

        // get selected row data From table to textfields
        table.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e){

                // i = the index of the selected row
                int i = table.getSelectedRow();

                textName.setText(model.getValueAt(i, 0).toString());
                textUnit.setText(model.getValueAt(i, 1).toString());
                textCode.setText(model.getValueAt(i, 2).toString());
                textCountry.setText(model.getValueAt(i, 3).toString());
                textRate.setText(model.getValueAt(i, 4).toString());
                textChange.setText(model.getValueAt(i, 5).toString());


            }
        });


        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                String text = searchField.getText();

                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                String text = searchField.getText();

                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });

    }
}


/*


    Currency[] currencies;
    JTable jt;
    int size;
    JLabel searchTag;
    JTextField searchBox;
    JButton searchButton;
    DefaultTableModel tableModel;
    String[][] data;
    String[] columns;
    JScrollPane jp;


    Table(Currency[] currencies, int rSize) {
        InitTable(currencies, rSize);
        GuiBuilder();
    }

    public void InitTable(Currency[] currencies, int rSize){
        size = rSize;
        columns = new String[]{"Name", "Unit", "Code", "Country", "Rate", "Change"};
        data = new String[size][6];
        for (int i = 0; i < size; i++) {
            data[i][0] = currencies[i].getName();
            data[i][1] = Double.toString(currencies[i].getUnit());
            data[i][2] = currencies[i].getCode();
            data[i][3] = currencies[i].getCountry();
            data[i][4] = Double.toString(currencies[i].getRate());
            data[i][5] = Double.toString(currencies[i].getChange());
        }
        tableModel = new DefaultTableModel(data, columns);
    }

    public void GuiBuilder(){
        setLayout(new BorderLayout());
        setContentPane(new JLabel(new ImageIcon("../java Finel project/tableBack.png")));
        setLayout(new FlowLayout());
        setResizable(false);
        setLayout(null);
        setSize(600, 400);
        setTitle("curr.Currency Exchange Rates- curr.Table");

        jt = new JTable(tableModel);
        jt.setPreferredScrollableViewportSize(new Dimension(550, 350));
        jt.setFillsViewportHeight(true);
        jp = new JScrollPane(jt);
        searchTag = new JLabel("search by name");
        searchBox = new JTextField("", 20);
        searchButton = new JButton("Search!");

        add(searchTag);
        add(searchBox);
        add(jp);
        add(searchButton);
        jp.setBounds(10, 60, 550, 245);
        searchBox.setBounds(10, 25, 150, 20);
        searchTag.setBounds(10, 5, 200, 15);
        searchButton.setBounds(170, 25, 90, 20);

        SearchHandler searchHandler = new SearchHandler();
        searchButton.addActionListener(searchHandler);

        DefaultTableModel tableModel1 = new DefaultTableModel(data, columns) {
            public boolean isCellEditable(int row, int column) {
                return false;//This causes all cells to be not editable
            }
        };
        jt.setModel(tableModel1);

    }

    private class SearchHandler implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            List<String> removalList = new ArrayList<String>();
            int tArrSize = size, sArrSize = size;
            String input = searchBox.getText();
            for (int i = 0; i < tArrSize; i++) {
                if (!data[i][0].equals(input)) {
                    removalList.add(data[i][2]);
                }
            }
            for(int j = 0; j < removalList.size(); j++) {
                for(int f = 0; f < tArrSize; f++){
                    if(data[f][2].equals(removalList.get(j))) {
                        tableModel.removeRow(f);
                        break;
                    }
                }
                tArrSize = sArrSize--;
            }

           // tableModel = new DefaultTableModel(data, columns);

            jt.tableChanged(new TableModelEvent(tableModel));
            jt.validate();
            jp.revalidate();
            jp.repaint();
        }
    }
}
*/
