package curr;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HistoryManger {
    List<CurrencyHistory> data = new ArrayList<CurrencyHistory>();
    public void WritData(){

    }
    public void ReadData() throws IOException {
        FileReader file = null;
        try {
            file  =  new FileReader("data.txt");

        }catch (FileNotFoundException e) {
            Model.log.error(e);
            e.printStackTrace();
        }
        BufferedReader reader = new BufferedReader(file);
        String line = "";
        line = reader.readLine();
        line =reader.readLine();
        while ((line = reader.readLine()) != null)   {

        }
    }

    public static void main(String[] args) throws IOException {
        HistoryManger hm = new HistoryManger();
        try {
            hm.ReadData();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

class CurrencyHistory{
    List<String> dates;
    List<Double> rates;
    String name;
    String code;

    public CurrencyHistory(List<String> dates, List<Double> rates, String name, String code) {
        this.dates = dates;
        this.rates = rates;
        this.name = name;
        this.code = code;
    }
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List<String> getDates() {
        return dates;
    }

    public void setDates(List<String> dates) {
        this.dates = dates;
    }

    public List<Double> getRates() {
        return rates;
    }

    public void setRates(List<Double> rates) {
        this.rates = rates;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void Addinfo(String date,double rate){
        dates.add(date);
        rates.add(rate);
    }
}
