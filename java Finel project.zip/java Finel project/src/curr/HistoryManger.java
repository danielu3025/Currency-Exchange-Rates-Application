package curr;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class HistoryManger {
    Currency [] currarr ;
    String dateInfo;
    PrintWriter pw;
    public HistoryManger(Currency[] currencies ,String date) throws FileNotFoundException, UnsupportedEncodingException {
        currarr =currencies;
        dateInfo = date;
    }
    public void ArchivedCurrenciesInfo() throws IOException {
        FileReader file = null;
        String[] lines = new String[currarr.length];
        try {
            file  =  new FileReader("history.txt");


        }catch (FileNotFoundException ex) {
            CurrencyHolder.log.error(ex);
            ex.printStackTrace();
        }

        BufferedReader reader = new BufferedReader(file);
        for(int i =0 ; i<currarr.length;i++){
            lines[i] = reader.readLine() + dateInfo +","+ currarr[i].getRate();
        }
        pw = new PrintWriter("history.txt", "UTF-8");
        for(int i =0 ; i<currarr.length;i++){
            pw.println(lines[i]+"#");
        }
        pw.close();
    }
    public CurrencyHistoryObj[] LoadDataHistory() throws IOException {
        CurrencyHistoryObj[] currencyHistoryObj = null;
        String[] lines = null;
        FileReader file = null;
        String[] spiltString;
        String[] spiltString2;

        try {
            file  =  new FileReader("history.txt");
            lines = new String[currarr.length];

        }catch (FileNotFoundException ex) {
            CurrencyHolder.log.error(ex);
            ex.printStackTrace();
        }
        String name;
        List<String> dateArr = new ArrayList<String>();
        List<Double> ratesArr = new ArrayList<Double>();
        currencyHistoryObj = new CurrencyHistoryObj[currarr.length];
        BufferedReader reader = new BufferedReader(file);
        for(int i =0 ; i<currarr.length;i++){
            lines[i] = reader.readLine();
            spiltString = lines[i].split(":",-1);
            name = spiltString[0];
            lines[i] = spiltString[1];
            spiltString = lines[i].split("#",-1);

            for(int j =0 ; j<spiltString.length-1;j++){
                spiltString2 = spiltString[j].split(",",-1);
                dateArr.add(spiltString2[0]);
                ratesArr.add(Double.parseDouble(spiltString2[1]));
            }
            currencyHistoryObj[i] = new CurrencyHistoryObj(name,dateArr,ratesArr);
            dateArr.clear();
            ratesArr.clear();
        }

        return  currencyHistoryObj;
    }
    class CurrencyHistoryObj{
        String name;
        List<String> dates ;
        List <Double> rates;

        public CurrencyHistoryObj(String name, List<String> dateList, List<Double>ratesList) {
            this.name = name;
            this.dates = new ArrayList<String>(dateList);
            this.rates = new ArrayList<Double>(ratesList);
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public List<String> getDates() {
            return dates;
        }

        public void setDates(List<String>dates) {
            this.dates = dates;
        }

        public List<Double> getRates() {
            return rates;
        }

        public void setRates(List<Double> rates) {
            this.rates = rates;
        }
    }


}
