package curr;

import java.io.*;

public class HistoryManger {
    Currency [] currarr ;
    String dateInfo;
    PrintWriter pw;
    public HistoryManger(Currency[] currencies ,String date) throws FileNotFoundException, UnsupportedEncodingException {
        currarr =currencies;
        dateInfo = date;
    }
    public void ArchivedCurrenciesInfo() throws IOException {
        FileReader file = null;
        String[] lines = new String[currarr.length];
        try {
            file  =  new FileReader("history.txt");


        }catch (FileNotFoundException ex) {
            CurrencyHolder.log.error(ex);
            ex.printStackTrace();
        }

        BufferedReader reader = new BufferedReader(file);
        for(int i =0 ; i<currarr.length;i++){
            lines[i] = reader.readLine() + dateInfo +","+ currarr[i].getRate();
        }
        pw = new PrintWriter("history.txt", "UTF-8");
        for(int i =0 ; i<currarr.length;i++){
            pw.println(lines[i]+"|");
        }
        pw.close();

    }

}
