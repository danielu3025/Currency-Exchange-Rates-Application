package curr;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class View extends JFrame  {
    Currency[] currenciesObjList;
    String  lastDate;
    Table table;
    Calculator calc;
    JLabel lblDateInfo;
    public View(Currency[] currencies , String date) throws IOException {
        currenciesObjList = currencies;
        lastDate = date;
        setSize(400,600);
        setTitle("Currencies Rate application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        lblDateInfo = new JLabel("Update to:" + lastDate);
        lblDateInfo.setBounds(250,400,300,300);
        lblDateInfo.setForeground (Color.white);

        Icon tableIcon = new ImageIcon("../java Finel project/btTableimg.png");
        JButton btOpenTable = new JButton(tableIcon);
        btOpenTable.setBounds(100,100,200,100);

        Icon calcIcon = new ImageIcon("../java Finel project/btCalcImg.png");
        JButton btOpenCalc = new JButton(calcIcon);
        btOpenCalc.setBounds(100,210,200,100);

        Icon updateIcon = new ImageIcon("../java Finel project/btUpdateImg.png");
        JButton btUpdate = new JButton(updateIcon);
        btUpdate.setBounds(100,320,200,100);


        setLayout(new BorderLayout());
        setContentPane(new JLabel(new ImageIcon("../java Finel project/menuBackGround.png")));
        setLayout(new FlowLayout());
        setLayout(null);
        setResizable(false);
        add(btOpenTable);
        add(btOpenCalc);
        add(btUpdate);
        add(lblDateInfo);


        HendlerBtOpenCalc  hendlerBtopenCalc = new HendlerBtOpenCalc(currenciesObjList,lastDate);
        btOpenCalc.addActionListener(hendlerBtopenCalc);

        HendlerBtOpenTable  hendlerBtOpenTable = new HendlerBtOpenTable(currenciesObjList,currenciesObjList.length);
        btOpenTable.addActionListener(hendlerBtOpenTable);

        HendlerUpdate  hendlerUpdate = new HendlerUpdate();
        btUpdate.addActionListener(hendlerUpdate);

        setVisible(true);

    }


    private class  HendlerBtOpenCalc implements ActionListener {
        Currency[] currencies ;
        String date;
        public HendlerBtOpenCalc(Currency[] currencies, String date) {
            this.currencies = currencies;
            this.date = date;
            calc = new Calculator(currencies,date) ;
        }
        public void actionPerformed(ActionEvent e) {
            if (!(calc.isVisible())){
                calc.setVisible(true);
            }
        }

    }
    private class HendlerBtOpenTable implements ActionListener {
        int length;
        Currency[] currencies ;
        public HendlerBtOpenTable(Currency[] currencies, int length) {
            this.length = length;
            this.currencies = currencies;
            table = new Table(currencies,currencies.length);
        }
        public void actionPerformed(ActionEvent e) {
            if (!(table.isVisible())){
                table.setVisible(true);
            }
        }
    }
    private class  HendlerUpdate implements ActionListener {
        public  Logger log = LogManager.getLogger(CurrencyHolder.class.getName());

        public void actionPerformed(ActionEvent e) {
            CurrencyHolder.FatchInfo fd  = new CurrencyHolder.FatchInfo();
            try {
                fd.loadData();
            } catch (FileNotFoundException ex) {
                log.error("File not found!");
                ex.printStackTrace();
            } catch (UnsupportedEncodingException ex) {
                log.error("Encode is unknown!");
                ex.printStackTrace();
            }

            CurrencyHolder.FileRead fr = new CurrencyHolder.FileRead();
            try {
                fr.LoadFile();
            } catch (IOException e1) {
                e1.printStackTrace();
            }

            currenciesObjList =  fr.GetCurrencies();
            lastDate = fr.GetUPToDate();
            table.dispose();
            calc.dispose();
            lblDateInfo.setText("Update to:"+lastDate);
        }
    }

}
