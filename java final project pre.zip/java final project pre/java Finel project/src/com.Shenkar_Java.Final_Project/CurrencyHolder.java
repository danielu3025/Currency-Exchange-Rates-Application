package com.Shenkar_Java.Final_Project;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;


public class CurrencyHolder {

    public static Logger log = LogManager.getLogger(CurrencyHolder.class.getName());

    public static void main(String[] args) throws IOException {
        Currency[] currencys = null;
        String lastDateUpDate = "" ;
        FatchInfo fd  = new FatchInfo();
        try {
            //load data from the web and backup it in file
           currencys = fd.loadData();
            CurrencyHolder.log.info("fatch data - succesed");
            lastDateUpDate = fd.getLastDate();
            //archive currency history info
            HistoryManger hm = new HistoryManger(currencys,lastDateUpDate);
            hm.ArchivedCurrenciesInfo();
            hm.LoadDataHistory();
            //lunch user interface
            View ui = new View(currencys,lastDateUpDate);


        } catch (FileNotFoundException e) {
            log.error("File not found!");
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            log.error("Encode is unknown!");
            e.printStackTrace();
        }

    }
    public static class FileRead {
        int size = 0;
        String date = "";
        Currency[] currencies;
        String[] spiltString;
        public void LoadFile  () throws IOException {
            FileReader file = null;
            try {
                file  =  new FileReader("data.txt");

            }catch (FileNotFoundException e) {
                CurrencyHolder.log.error(e);
                e.printStackTrace();
            }
            BufferedReader reader = new BufferedReader(file);

            String line  = reader.readLine();
            size = Integer.parseInt(line);
            line = reader.readLine();
            date = line;
            currencies = new Currency[size];
            //create an array of currencies from text file
            for(int i = 0 ; i<size; i++){
                line = reader.readLine();
                spiltString = line.split(",",-1);
                currencies[i] = new Currency(spiltString[0],spiltString[1],spiltString[2],spiltString[3],spiltString[4],spiltString[5]);
            }
        }
        public Currency[] GetCurrencies() {return currencies;}
        public String GetUPToDate(){
            return date;
        }
    }
    public static class FatchInfo{
        String lastDate;
        public  Currency[] loadData () throws FileNotFoundException, UnsupportedEncodingException {
            PrintWriter writer = null;
            InputStream is = null;
            Currency[] currencies = null;
            HttpURLConnection con = null;
            try
            {
                //connect to web data source
                URL url = new URL("http://www.boi.org.il/currency.xml");
                HttpURLConnection.setFollowRedirects(false);
                con = (HttpURLConnection)url.openConnection();
                con.setRequestMethod("GET");
                con.connect();
                is = con.getInputStream();
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();
                Document doc = builder.parse(is);
                doc.normalizeDocument();
                //open text file to save this information locale
                writer = new PrintWriter("data.txt", "UTF-8");
                //parsing the xml
                NodeList rootNodes = doc.getElementsByTagName("CURRENCIES");
                Node root = rootNodes.item(0);
                Element rootElement = (Element) root;
                NodeList dateList  = rootElement.getElementsByTagName("LAST_UPDATE");
                Node upDateNode = dateList.item(0);
                Element upDate = (Element) upDateNode;
                NodeList currenciesList  = rootElement.getElementsByTagName("CURRENCY");
                writer.println(currenciesList.getLength());
                writer.println(upDate.getTextContent());
                lastDate = upDate.getTextContent();
                //create currencies array for the app
                currencies = new Currency[currenciesList.getLength()];
                for(int i = 0 ; i<currenciesList.getLength();i++){
                    Node aCurrency =  currenciesList.item(i);
                    Element currencyElement = (Element) aCurrency;
                    Node nameTag = currencyElement.getElementsByTagName("NAME").item(0);
                    Element name = (Element) nameTag;
                    Node unitTag = currencyElement.getElementsByTagName("UNIT").item(0);
                    Element unit = (Element) unitTag;
                    Node currencyCodeTag =currencyElement.getElementsByTagName("CURRENCYCODE").item(0);
                    Element currencyCode = (Element) currencyCodeTag;
                    Node countryTag = currencyElement.getElementsByTagName("COUNTRY").item(0);
                    Element country = (Element) countryTag;
                    Node rateTag = currencyElement.getElementsByTagName("RATE").item(0);
                    Element rate = (Element) rateTag;
                    Node changeTag = currencyElement.getElementsByTagName("CHANGE").item(0);
                    Element change = (Element) changeTag;
                    currencies[i] = new Currency(name.getTextContent(),unit.getTextContent(),currencyCode.getTextContent(),country.getTextContent(),rate.getTextContent(),change.getTextContent());
                    writer.println(name.getTextContent() + "," + unit.getTextContent() + "," + currencyCode.getTextContent() +
                            "," + country.getTextContent() + "," + rate.getTextContent() + "," + change.getTextContent());
                    CurrencyHolder.log.info("xml was parsed into data structure");
                    CurrencyHolder.log.info("xml was parsed into file");

                }
                writer.close();
            }
            catch(IOException e)
            {
                CurrencyHolder.log.error("Cannot fetch data  from the web! Returns NULL");
                e.printStackTrace();

                FileRead fr = new FileRead();
                fr.LoadFile();
                currencies = fr.GetCurrencies();
                lastDate = fr.GetUPToDate();


            }
            catch(ParserConfigurationException e)
            {
                CurrencyHolder.log.error("Cannot parse XML file!");
                e.printStackTrace();
            }
            catch(SAXException e)
            {
                CurrencyHolder.log.error("Cannot parse XML file!");
                e.printStackTrace();

            }
            finally
            {
                if(is!=null)
                {
                    try
                    {
                        is.close();
                    }
                    catch(IOException e)
                    {
                        e.printStackTrace();
                    }
                }
                if(con!=null)
                {
                    con.disconnect();
                }
                return currencies;
            }
        }
        String getLastDate(){
            return this.lastDate;
        }
    }
}
