package com.Shenkar_Java.Final_Project;

import static org.junit.Assert.*;

import org.junit.Test;

public class testing {
    @Test
    public void Test(){
        double curr = Calculator.Conversion(3.6928,0.0250978,100,10,"10");
        //need to update results (the left data) manually
        assertEquals(147.5,curr,3.0);
    }
}
